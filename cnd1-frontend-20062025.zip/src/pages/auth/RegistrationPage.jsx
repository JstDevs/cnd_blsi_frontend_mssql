import React from 'react';

const RegistrationPage = () => {
  return (
    <div>
      <h1>Registration Page</h1>
      {/* Add your registration form here */}
    </div>
  );
};

export default RegistrationPage; 