import React from 'react';

const ResetPasswordPage = () => {
  return (
    <div>
      <h1>Reset Password Page</h1>
      {/* Add your reset password form here */}
    </div>
  );
};

export default ResetPasswordPage; 