import React from 'react';

const ForgotPasswordPage = () => {
  return (
    <div>
      <h1>Forgot Password Page</h1>
      {/* Add your forgot password form here */}
    </div>
  );
};

export default ForgotPasswordPage; 